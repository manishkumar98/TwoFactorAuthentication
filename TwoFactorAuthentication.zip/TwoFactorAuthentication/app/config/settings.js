module.exports = {
    mongodb: "mongodb://localhost/node-2fa"
}