# node-2fa
Sample code for Two-factor authentication with Node.js presentation.

Slides: http://www.slideshare.net/IlyaVerbitskiy1/two-factor-authentication-with-nodejs-58775485

## Installation

```bash
$ cd ./app
$ npm install
$ npm start
```

Open your web browser and go to http://localhost:3000/